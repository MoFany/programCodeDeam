#include"stdio.h"
void main()
{
	int p=1;
	int i; 
	for(i=p+1;i<=11;i+=2)
	{p=p*i;}
	printf("%d\n",p);

}