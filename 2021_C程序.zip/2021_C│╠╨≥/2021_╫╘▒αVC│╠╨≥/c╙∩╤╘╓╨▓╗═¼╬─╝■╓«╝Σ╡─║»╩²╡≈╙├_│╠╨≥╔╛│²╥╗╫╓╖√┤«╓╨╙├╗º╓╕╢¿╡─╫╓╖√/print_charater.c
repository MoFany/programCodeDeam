void print_charater(char str[])
	{
	printf("%s\n",str);
	}
